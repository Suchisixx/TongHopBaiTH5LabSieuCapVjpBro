package com.example.lab4_bt1_btth;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class M001RegisterFragment extends Fragment implements View.OnClickListener {

    private EditText etEmail, etPassword, etConfirmPass;
    private Context mContext;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mContext = context;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Liên kết với file giao diện XML đăng ký
        View rootView = inflater.inflate(R.layout.m001_act_register, container, false);
        initView(rootView);
        return rootView;
    }

    private void initView(View v) {
        // Ánh xạ đúng các ID trong file XML đăng ký của bạn
        etEmail = v.findViewById(R.id.et_email);
        etPassword = v.findViewById(R.id.et_password);
        etConfirmPass = v.findViewById(R.id.et_confirm_password);

        // Nút Back (Mũi tên quay lại)
        ImageView ivBack = v.findViewById(R.id.iv_back);
        if (ivBack != null) {
            ivBack.setOnClickListener(this);
        }

        // Nút Đăng ký (Trong XML bạn đặt ID nó là tv_login nên mình gọi theo ID đó)
        v.findViewById(R.id.tv_login).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        v.startAnimation(AnimationUtils.loadAnimation(mContext, androidx.appcompat.R.anim.abc_fade_in));

        if (v.getId() == R.id.iv_back) {
            // Quay về màn hình đăng nhập
            ((MainActivity) mContext).gotoLoginScreen();
        } else if (v.getId() == R.id.tv_login) {
            // Thực hiện đăng ký
            handleRegister();
        }
    }

    private void handleRegister() {
        String email = etEmail.getText().toString().trim();
        String pass = etPassword.getText().toString().trim();
        String rePass = etConfirmPass.getText().toString().trim();

        // 1. Kiểm tra nhập thiếu
        if (email.isEmpty() || pass.isEmpty() || rePass.isEmpty()) {
            Toast.makeText(mContext, "Nhập thiếu thông tin rồi!", Toast.LENGTH_SHORT).show();
            return;
        }

        // 2. Kiểm tra mật khẩu nhập lại
        if (!pass.equals(rePass)) {
            Toast.makeText(mContext, "Mật khẩu xác nhận không khớp!", Toast.LENGTH_SHORT).show();
            return;
        }

        SharedPreferences pref = mContext.getSharedPreferences(MainActivity.SAVE_PREF, Context.MODE_PRIVATE);

        // 3. Kiểm tra xem email đã tồn tại chưa
        if (pref.getString(email, null) != null) {
            Toast.makeText(mContext, "Email này đã tồn tại!", Toast.LENGTH_SHORT).show();
            return;
        }

        // 4. Lưu thông tin (Key là email, Value là pass)
        pref.edit().putString(email, pass).apply();

        Toast.makeText(mContext, "Đăng ký thành công!", Toast.LENGTH_SHORT).show();

        // 5. Quay về màn hình đăng nhập ngay sau khi đăng ký xong
        ((MainActivity) mContext).gotoLoginScreen();
    }
}
